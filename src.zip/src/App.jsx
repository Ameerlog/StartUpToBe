import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./components/Home";
import HomePage from "./pages/HomePage";
import Mainlayout from "./layouts/Mainlayout";

function App() {
  return (
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Mainlayout />} />
    </Routes>
      <Routes>
        <Route path="/home" element={<HomePage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
