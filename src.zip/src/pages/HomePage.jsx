import React from 'react'

const HomePage = () => {
  return (
    <div>
      <h2>Homepage</h2>
    </div>
  )
}

export default HomePage
