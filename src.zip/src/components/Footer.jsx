import { Instagram, Linkedin, Twitter, ArrowUpRight } from "lucide-react";

export default function TabletFooter() {
  return (
    <footer className="bg-[#001E36] mt-20 rounded-[50px]  z-20 m-6 ">
      <div className="mx-auto max-w-[1440px] px-4 md:px-[64px] py-8 pb-[60px]">
        <div className="flex flex-col items-center text-center gap-10
                        md:flex-row md:items-start md:text-left md:justify-between
                        lg:grid lg:grid-cols-3 lg:gap-8 mt-10">

          <div className="flex flex-col items-center md:items-start gap-6">
            <img
              src="/images/logo.png" 
              alt="Startup Logo"
              className="h-10 md:h-12 lg:h-14 object-contain"
            />

            <div className="flex gap-4">
              <a
                href="https://x.com/jointhefoundery"
                className="text-white hover:text-[#28B463]"
                aria-label="X"
              >
                <Twitter className="w-8 h-8 lg:w-10 lg:h-10" />
              </a>

              <a
                href="https://www.instagram.com/jointhefoundery/"
                className="text-white hover:text-[#28B463]"
                aria-label="Instagram"
              >
                <Instagram className="w-8 h-8 lg:w-10 lg:h-10" />
              </a>

              <a
                href="https://www.linkedin.com/company/thefounderyindia/"
                className="text-white hover:text-[#28B463]"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-8 h-8 lg:w-10 lg:h-10" />
              </a>
            </div>
          </div>

          <div className="w-full md:w-auto lg:justify-self-center">
            <h4 className="text-[20px] md:text-[24px] font-light text-white mb-4 font-gilvenir">
              Home
            </h4>

            <ul className="space-y-3">
              <li>
                <a
                  href="/#mentor"
                  className="text-[#FFFFFFCC] text-[18px] lg:text-[22px] font-nunito-sans font-medium"
                >
             Solutions
                </a>
              </li>

              <li>
                <a
                  href="/#journey"
                  className="text-[#FFFFFFCC] text-[18px] lg:text-[22px] font-nunito-sans font-medium"
                >
               Domains for Sale
                </a>
              </li>

              <li>
                <a
                  href="/#archetypes"
                  className="text-[#FFFFFFCC] text-[18px] lg:text-[22px] font-nunito-sans font-medium"
                >
                 Branding and Naming
                </a>
              </li>
                <li>
                <a
                  href="/#archetypes"
                  className="text-[#FFFFFFCC] text-[18px] lg:text-[22px] font-nunito-sans font-medium"
                >
             Company Registration
                </a>
              </li>
            </ul>
          </div>

          <div className="w-full md:w-auto lg:text-right">
            <p className="text-[22px] md:text-[24px] font-bold font-gilvenir text-white">
              Get in Touch with us
            </p>

            <p className="mt-3 font-nunito-sans text-[18px] lg:text-[22px] font-medium text-[#FFFFFFCC]">
              Got questions, ideas, or something we should know?
            </p>

            <a
              href="/contact-us"
              className="mt-6 inline-flex items-center gap-2
                         bg-amber-400 text-black
                         font-nunito-sans font-bold uppercase
                         px-6 py-3 rounded-full
                         hover:opacity-90 transition"
            >
              Contact Us
              <ArrowUpRight className="w-5 h-5" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
