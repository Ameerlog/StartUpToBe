const items = [
  {
    title: "Brand Identity",
    desc: "Unique brand names, premium domains, and trademarks that give your startup instant credibility",
   
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 112 112" width="112" height="112" preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%" }}>
        <defs>
          <clipPath id="__lottie_element_concepts">
            <rect width="112" height="112" x="0" y="0" />
          </clipPath>
        </defs>
        <g clipPath="url(#__lottie_element_concepts)">
          <g opacity="1">
            <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
              d="M46.667,102.666 C46.667,102.666 65.334,102.666 65.334,102.666" />
          </g>
          <g opacity="1" transform="matrix(0.9979555606842041,-0.06391138583421707,0.06391138583421707,0.9979555606842041,-5.573112487792969,3.7769699096679688)">
            <g opacity="1" transform="matrix(1,0,0,1,56,51.332000732421875)">
              <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
                d="M-32.666,-5.895 C-32.666,-23.257 -18.041,-37.334 0.001,-37.334 C18.042,-37.334 32.667,-23.257 32.667,-5.895 C32.667,3.623 28.273,12.153 21.33,17.918 C18.397,20.354 15.876,23.377 14.918,27.066 C14.918,27.066 13.612,32.093 13.612,32.093 C12.81,35.179 10.025,37.334 6.837,37.334 C6.837,37.334 -6.835,37.334 -6.835,37.334 C-10.024,37.334 -12.809,35.179 -13.61,32.093 C-13.61,32.093 -14.916,27.066 -14.916,27.066 C-15.875,23.377 -18.396,20.354 -21.329,17.918 C-28.271,12.153 -32.666,3.623 -32.666,-5.895z" />
            </g>
          </g>
          <g opacity="1" transform="matrix(1,0,0,1,0,0)">
            <g opacity="1" transform="matrix(1,0,0,1,55.99700164794922,46.6619987487793)">
              <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
                d="M1.798,-15.4 C1.798,-15.4 -6.771,-2.8 -6.771,-2.8 C-7.333,-2.039 -6.798,-1.055 -5.723,-0.881 C-5.723,-0.881 5.729,0.976 5.729,0.976 C6.795,1.149 7.333,2.12 6.785,2.881 C6.785,2.881 5.864,4.065 4.589,5.705" />
            </g>
          </g>
        </g>
      </svg>
    ),
  },

  {
    title: "Legal & Compliance",
    desc: "Company registration, GST, trademark & IP filings handled end-to-end",
    // SVG taken from your paste (Capital icon)
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 112 112" width="112" height="112" preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%" }}>
        <defs>
          <clipPath id="__lottie_element_capital">
            <rect width="112" height="112" x="0" y="0" />
          </clipPath>
        </defs>
        <g clipPath="url(#__lottie_element_capital)">
          <g opacity="1">
            <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
              d="M18.666,60.667 C18.666,60.667 18.666,84 18.666,84 M42,60.667 C42,60.667 42,84 42,84 M70,60.667 C70,60.667 70,84 70,84 M93.333,60.667 C93.333,60.667 93.333,84 93.333,84" />
          </g>
          <g opacity="1" transform="matrix(1,0,0,1,56,27.948999404907227)">
            <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
              d="M46.667,18.718 C46.667,18.718 -46.667,18.718 -46.667,18.718 C-46.667,18.718 -46.667,14.051 -46.667,14.051 C-46.667,14.051 -8.96,-14.229 -8.96,-14.229 C-5.747,-16.638 -4.141,-17.843 -2.376,-18.308 C-0.819,-18.718 0.818,-18.718 2.376,-18.308 C4.14,-17.843 5.747,-16.638 8.96,-14.229 C8.96,-14.229 46.667,14.051 46.667,14.051 C46.667,14.051 46.667,18.718 46.667,18.718z" />
          </g>
          <g opacity="1">
            <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
              d="M9.333,98 C9.333,98 102.667,98 102.667,98" />
          </g>
        </g>
      </svg>
    ),
  },

  {
    title: "Digital Presence",
    desc: "Websites, content, and social media setup to launch your brand from day one..",
    // SVG taken from your paste (Clarity icon)
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 112 112" width="112" height="112" preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%" }}>
        <defs>
          <clipPath id="__lottie_element_clarity">
            <rect width="112" height="112" x="0" y="0" />
          </clipPath>
        </defs>
        <g clipPath="url(#__lottie_element_clarity)">
          <g opacity="1" transform="matrix(1,0,0,1,56,56)">
            <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
              d="M0,45.162 C1.502,45.162 3.004,45.006 4.481,44.692 C7.19,44.116 9.769,42.813 14,40.407
                 M0,45.162 C-1.502,45.162 -3.004,45.006 -4.482,44.692 C-7.191,44.116 -9.769,42.813 -14,40.407
                 M0,45.162 C0,45.162 0,32.666 0,32.666
                 M0,-45.162 C1.502,-45.162 3.004,-45.006 4.481,-44.692 C7.19,-44.116 9.769,-42.813 14,-40.407
                 M0,-45.162 C-1.502,-45.162 -3.004,-45.006 -4.482,-44.692 C-7.191,-44.116 -9.769,-42.813 -14,-40.407
                 M0,-45.162 C0,-45.162 0,-32.666 0,-32.666" />
          </g>
          <g opacity="1">
            <path strokeLinecap="round" strokeLinejoin="round" fillOpacity="0" stroke="rgb(40,180,98)" strokeOpacity="1" strokeWidth="4"
              d="M56,70 C56,70 56,56 56,56" />
          </g>
        </g>
      </svg>
    ),
  },

  {
    title: "Outsourcing & Support",
    desc: "Back-office, customer support, and execution teams so founders stay focused.",
    // SVG taken from your paste (Community icon)
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 112 112" width="112" height="112" preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%" }}>
        <defs>
          <clipPath id="__lottie_element_community">
            <rect width="112" height="112" x="0" y="0" />
          </clipPath>
        </defs>

        <g clipPath="url(#__lottie_element_community)">
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            fillOpacity="0"
            stroke="rgb(40,180,98)"
            strokeOpacity="1"
            strokeWidth="4"
            d="M43.606,5.767 C39.145,-0.57 31.176,-5.59 23.227,-5.59 C12.746,-5.59 5.546,-0.19 0,5.767
               C-7.866,-5.766 -21.804,-5.557 -21.804,-5.557 C-30.815,-5.557 -38.784,-1.081 -43.606,5.767"
            transform="translate(56.002 92.232)"
          />
          <circle
            cx="34.199"
            cy="74.563"
            r="12.113"
            stroke="rgb(40,180,98)"
            strokeWidth="4"
            fill="none"
          />
          <circle
            cx="77.805"
            cy="74.563"
            r="12.113"
            stroke="rgb(40,180,98)"
            strokeWidth="4"
            fill="none"
          />
        </g>
      </svg>
    ),
  },

  {
    title: " Operations & Software",
    desc: "Accounting, CRM, operational tools, and workflows built to scale.",
    // SVG taken from your paste (Culture icon)
    icon: (
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 112 112" width="112" height="112" preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%" }}>
        <defs>
          <clipPath id="__lottie_element_culture">
            <rect width="112" height="112" x="0" y="0" />
          </clipPath>
        </defs>
        <g clipPath="url(#__lottie_element_culture)">
          <g opacity="1" transform="matrix(1,0,0,1,56,53.95800018310547)">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              fillOpacity="0"
              stroke="rgb(40,180,98)"
              strokeOpacity="1"
              strokeWidth="4"
              d="M0,44.041 C-24.889,44.041 -33.512,28.295 -33.512,9.629 C-33.512,-2.661 -24.996,-17.874 -18.016,-26.788
                 C-8.063,-21.396 -11.699,-11.679 -11.699,-11.679 C-2.349,-11.679 7.055,-20.815 0.102,-38.871
                 C17.988,-30.773 32.838,-17.801 32.838,7.607 C32.838,26.273 24.889,44.041 0,44.041z"
            />
          </g>
          <g opacity="1" transform="matrix(1,0,0,1,57.388999938964844,78.13700103759766)">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              fillOpacity="0"
              stroke="rgb(40,180,98)"
              strokeOpacity="1"
              strokeWidth="4"
              d="M-1.389,19.861 C2.637,19.859 6.738,18.6 9.833,15.901
                 C16.133,10.306 16.877,3.443 15.176,-2.869
                 C13.249,-10.593 7.306,-16.57 3.57,-19.815
                 C-3.922,-16.069 -24.197,-1.497 -16.02,12.34
                 C-13.062,17.381 -7.133,19.865 -1.389,19.861z"
            />
          </g>
        </g>
      </svg>
    ),
  },
];
export default function JourneySection() {
  return (
    <section id="journey" className="w-full bg-[#979899]">
      <section className="py-16 px-4 md:px-8 lg:px-16 flex flex-col justify-center items-center text-white mb-40">
        <div className="max-w-7xl mx-auto relative w-full">
          <div className="relative flex flex-col items-center sm:mt-5">
            <div className="text-start sm:text-center p-2">
              <h1 className="text-[36px] lg:text-[68px] font-[Roboto] text-black md:max-w-[560px] lg:max-w-[900px] leading-[114%] tracking-[-0.04em] font-gilvenir">
                <span>Our Philosophy</span>
              </h1>
            </div>

            <div className="text-center mt-4 p-2">
              <p className="text-black/70 md:max-w-[480px] lg:max-w-[720px] w-full text-base md:text-[18px] lg:text-[22px] leading-[135%] font-nunito-sans text-start sm:text-center tracking-[-0.02em]">
              Great companies don’t start with luck. 

                {/* <span className="lg:font-bold lg:text-black"> you start with firepower.</span>{" "} */}
                They start with clarity, identity, and execution. 
              </p>
            </div>

   
            <div className="hidden lg:block absolute left-[-20px] bottom-[-180px] transform -translate-x-8 translate-y-8 z-10 opacity-30">
              <img className="h-[320px]" src="/images/svg/lines-6.png" alt="" />
            </div>
            <div className="hidden lg:block absolute right-[-20px] bottom-[-180px] transform translate-x-8 translate-y-8 z-10 opacity-30">
              <img className="h-[320px]" src="/images/svg/lines-12.png" alt="" />
            </div>
          </div>

          <div className="relative mt-[40px] md:mt-[80px]">
      
            <div className="hidden md:flex justify-center flex-wrap max-w-7xl gap-[16px] md:gap-[24px] lg:gap-[32px] items-center">
              {items.map((item) => (
                <div
                  key={item.title}
                  className="bg-gray-800/5 border border-white/10 w-full md:max-w-[312px] lg:max-w-[368px] md:h-[320px] md:p-[40px] rounded-2xl backdrop-blur"
                >
                  <div className="hidden md:flex flex-col items-center text-center h-full justify-center">
                    <div className="mb-4 text-black" style={{ width: 112, height: 112 }}>
                      {item.icon}
                    </div>
                    <p className="text-[18px] md:text-[22px] lg:text-[24px] font-bold leading-[114%] tracking-[-0.02em] font-gilvenir mb-2 text-black">
                      {item.title}
                    </p>
                    <p className="text-[16px] md:text-[18px] lg:text-[22px] font-normal font-nunito-sans leading-[135%] tracking-[-0.02em] text-black/70">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* mobile */}
            <div className="md:hidden flex justify-center flex-wrap max-w-7xl gap-[16px] items-center mt-6">
              {items.map((item) => (
                <div key={item.title} className="bg-white/5 border border-white/10 w-full rounded-2xl backdrop-blur">
                  <div className="flex items-start gap-4 h-full justify-between px-[24px] py-[20px]">
                    <div className="max-w-[214px]">
                      <p className="font-bold text-[18px] font-gilvenir leading-[114%] tracking-[-0.02em] mb-1 text-left text-white">
                        {item.title}
                      </p>
                      <p className="text-[16px] font-normal font-nunito-sans leading-[135%] tracking-[-0.02em] text-left text-white/70">
                        {item.desc}
                      </p>
                    </div>

                    <div className="flex-shrink-0 text-white" style={{ width: 80, height: 80 }}>
                      <div className="w-full h-full [&>svg]:w-full [&>svg]:h-full">
                        {item.icon}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>
      </section>
    </section>
  );
}
