'use client';

import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import img from "../assets/herobg.jpeg";

const HeroSection = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [wordIndex, setWordIndex] = useState(0);

  const rotatingPhrases = useMemo(
    () => ['Cold‑Start  ', 'All‑in‑One Platform', 'Speed & Simplicity ', 'Founder‑First'],
    []
  );

  useEffect(() => {
    const id = setInterval(() => {
      setWordIndex((i) => (i + 1) % rotatingPhrases.length);
    }, 5000);

    return () => clearInterval(id);
  }, [rotatingPhrases.length]);

  const handleSearch = (e) => {
    e.preventDefault();
    console.log('Search:', searchQuery);
  };

  const lineTwo = {
    hidden: { opacity: 0, y: 12, clipPath: 'inset(0 0 100% 0)' },
    show: {
      opacity: 1,
      y: 0,
      clipPath: 'inset(0 0 0% 0)',
      transition: { duration: 1.5, ease: [0.22, 1, 0.36, 1] },
    },
  };

  const subCopy = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0, transition: { duration: 1, delay: 0.08 } },
  };

  const bgUrl = typeof img === "string" ? img : img?.src;

  return (
    <section
      className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#122130] bg-cover bg-center bg-no-repeat"
      style={{ backgroundImage: `url(${bgUrl})` }}
      aria-labelledby="hero-heading"
    >

      <div className="absolute inset-0 bg-black/40" />

      <div className="relative mx-auto flex w-full max-w-6xl flex-col items-center px-4 py-14 sm:px-6 lg:px-8 lg:py-20">

        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="mb-10 flex w-full justify-center"
        >
          <motion.div
            whileHover={{ y: -2 }}
            transition={{ type: 'spring', stiffness: 300, damping: 22 }}
            className="group relative rounded-full bg-gradient-to-r from-[#f5e6e0] via-[#ffe1ef] to-[#eceffa] p-[1px] shadow-[0_25px_70px_rgba(15,23,42,0.18)]"
          >
            {/* <div className="rounded-full bg-white/70 px-5 py-3 backdrop-blur sm:px-6">
              <p className="text-center text-xs font-semibold tracking-tight text-[#1f2a4d] sm:text-sm">
                Lorem ipsum dolor sit amet.
              </p>

              <p className="mt-1 text-center text-[11px] text-[#44527a] sm:text-xs">
                Lorem ipsum dolor sit amet consectetur adipisicin.{' '}
                <a
                  href="https://www.atom.com/blog/for-the-fourth-time-atom-com-joins-the-inc-5000-list/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-semibold text-[#0e0e0e] underline underline-offset-2"
                >
                  Read More
                </a>
              </p>
            </div> */}

            <span className="pointer-events-none absolute inset-0 rounded-full bg-[radial-gradient(circle_at_30%_20%,rgba(52,88,255,0.22),transparent_55%)] opacity-0 blur-md transition-opacity duration-300 group-hover:opacity-100" />
          </motion.div>
        </motion.div>


        <motion.div
          initial="hidden"
          animate="show"
          className="mt-5 w-full max-w-4xl self-start text-left"
        >
          <h1
            id="hero-heading"
            className="text-5xl font-light leading-none tracking-tight sm:text-6xl md:text-7xl lg:text-8xl"
          >
            <span className="block">
              <span className="sr-only">{rotatingPhrases[wordIndex]}</span>

              <span
                aria-hidden="true"
                className="relative block h-[1.02em] "
              >
                <AnimatePresence mode="wait">
                  <motion.span
                    key={rotatingPhrases[wordIndex]}
                    initial={{ opacity: 0, y: 10, filter: 'blur(10px)' }}
                    animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
                    exit={{ opacity: 0, y: -10, filter: 'blur(10px)' }}
                    transition={{ duration: 0.5, ease: 'easeInOut' }}
                    className="absolute left-0 top-0 bg-white bg-clip-text text-transparent"
                  >
                    {rotatingPhrases[wordIndex]}
                  </motion.span>
                </AnimatePresence>
              </span>
            </span>

            <span className="block overflow-hidden">
              <motion.span
                variants={lineTwo}
                className="block bg-white bg-clip-text text-transparent"
              >
               Startup solutions company
              </motion.span>
            </span>
          </h1>

          <motion.p
            variants={subCopy}
            className="mt-6 max-w-2xl text-base text-white sm:text-xl"
          >
            Whether you’re launching your first company or scaling your next venture, we help you move 
from concept to execution with clarity, speed, and confidence. 
            <br className="hidden sm:block" />
            <span className="sm:ml-1">
          
            </span>
          </motion.p>
        </motion.div>

        <motion.form
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15, duration: 0.6 }}
          onSubmit={handleSearch}
          className="mt-10 w-full max-w-3xl"
        >
          <div className="relative rounded-[999px] bg-white px-4 py-2 shadow-[0_22px_80px_rgba(13,26,54,0.22)] ring-1 ring-[#f2c7c9] sm:px-6 sm:py-3">
            <div className="flex items-center gap-3 sm:gap-4">
              <div className="hidden text-[#9aa4c4] sm:inline-flex">
                <svg
                  className="h-5 w-5"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-4.35-4.35M5 11a6 6 0 1 1 12 0 6 6 0 0 1-12 0z"
                  />
                </svg>
              </div>

              <input
                id="top-search-input"
                type="search"
                name="search"
                autoComplete="off"
                className="w-full bg-transparent text-sm text-[#111827] placeholder:text-[#a1accd] focus:outline-none sm:text-base"
                placeholder="Find your perfect name now!"
                aria-label="Search the marketplace"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />

              <button
                type="submit"
                aria-label="Search"
                className="inline-flex shrink-0 items-center justify-center rounded-full bg-[#122130] px-6 py-2 text-sm font-semibold text-white shadow-[0_18px_40px_rgba(236,28,36,0.35)] transition hover:bg-[#122130] sm:px-8 sm:py-2.5 sm:text-base"
              >
                Search
              </button>
            </div>
          </div>
        </motion.form>
      </div>
    </section>
  );
};

export default HeroSection;
