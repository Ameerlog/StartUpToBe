export default function VideoSectionCard() {
  return (
    <section className="bg-[#001E36] rounded-b-[50px] -z-10 mx-6 mb-6 -mt-24 overflow-hidden relative">
      <div className="relative h-[415px] md:h-[260px] lg:h-[480px] w-full">
        <video
          className="absolute inset-0 w-full h-full object-cover"
          autoPlay
          loop
          playsInline
          muted
        >
          <source
            src="https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4"
            type="video/mp4"
          />
        </video>

        <div className="absolute inset-0 bg-[#000000CC] z-[1]" />


        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center gap-6">
          <img
            alt="Logo"
            src="/images/svg/updated_logo.svg"
            className="w-full max-w-[450px] md:max-w-[700px] lg:max-w-[900px]" // increased size
          />
          <p className="text-white font-gilvenir text-[50px] md:text-[60px] lg:text-[70px] leading-[114%] tracking-[-0.04em]">
            <span>StartUp</span>
            <span className="block text-2xl md:text-3xl lg:text-4xl font-Italian text-rose-500">
        Tobe
            </span>
          </p>
        </div>

        <div className="absolute bottom-0 left-0 w-full z-[20] px-4 pb-4 md:pb-6 lg:flex lg:justify-between flex-wrap text-[#FFFFFFCC] text-center">
          <div className="font-nunito-sans text-[16px] md:text-[18px] leading-[135%]">
            © 2025 Foundery. All rights reserved.
          </div>

          <div className="mt-1 flex flex-wrap justify-center gap-2">
            <a href="/terms-and-conditions" className="underline text-nowrap">
              Terms and Conditions
            </a>
            <a href="/privacy-and-policy" className="underline text-nowrap">
              Privacy Policy
            </a>
            <a href="/cancellation-and-refund-policy" className="underline text-nowrap">
              Refund Policy
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
