import React from 'react'
import Home from '../components/Home'
import JourneySection from '../components/Journey'
import Journey from '../components/Journey'
import AdvantageSection from '../components/Advantage'
import DomainSection from '../components/DomianSection'
import TabletFooter from '../components/Footer'
import VideoLogoFooterCard from '../components/Footerdown'



const Mainlayout = () => {
  return (
    <>
   <Home/>
<Journey/>
<AdvantageSection/>
<DomainSection/>
<TabletFooter/>
<VideoLogoFooterCard/>
   </>

  )
}

export default Mainlayout
